/**
 * Client half of `@elves-ai/dsh-web-search-firecrawl`: contributes the
 * "Firecrawl" page to the DSH Settings shell.
 *
 * 0.2.0-rc.2 port: the old fenced `/firecrawl/api` route is gone. The page
 * reads and writes the plugin's own profile entry through the shared
 * `configForms` service (`ConfigForms.get(entryId)`), keyed by this plugin's
 * profile entry id. The section registers itself while the Host serves the
 * entry's namespace so a composition without the plugin shows no trace.
 */
import type { Context } from '@deepseek-ai/cordis';
/** Required services before mounting. */
export declare const inject: string[];
/**
 * Register the Firecrawl settings section.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: Context & {
    slots: {
        register(options: object, component: unknown): () => void;
    };
    configForms: {
        whileServed: (namespaces: readonly string[], register: () => () => void) => () => void;
    };
}): void;
