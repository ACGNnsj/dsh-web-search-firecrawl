/**
 * The "Firecrawl" settings page contributed to the DSH Settings shell.
 *
 * 0.2.0-rc.2 port: reads and writes through the shared `configForms` service
 * addressed by this plugin's profile entry id. The API key is write-only in
 * the wire direction: the host schema marks it `role('secret')`, so this page
 * never receives the literal — it shows whether a key is configured (from the
 * shared describe mirror), accepts a replacement (blank = keep the current
 * key), and offers an explicit clear button. All commits apply live: the host
 * provider snapshots the volatile refs on the next search.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Props the settings shell binds for this section. */
export type FirecrawlSettingsSectionProps = PropsRuntime<'settings.section'> & {
    /** Host plugin entry id owning this form (the profile row id). */
    entryId?: string;
    /** Browser plugin context carrying `configForms`. */
    ctx?: ClientContext;
};
/**
 * Render the Firecrawl settings page.
 * @param props - the runtime share of a `settings.section` entry.
 * @returns the section element tree.
 */
export declare function FirecrawlSettingsSection(props: FirecrawlSettingsSectionProps): import("react").JSX.Element;
