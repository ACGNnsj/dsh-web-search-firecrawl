/**
 * `FirecrawlSearchProvider`: a `WebSearchProvider` backed by the Firecrawl search API
 * (`POST /v1/search`, with a `POST /v2/search` fallback for self-hosted
 * instances that only serve v2). It maps `title` to `title` and the
 * `description` excerpt (bounded by `maxSnippetChars`) to `snippet`, keeps
 * citeable URL-only entries when no description is present, and omits
 * `content` because Firecrawl returns no generated answer.
 * @module @elves-ai/dsh-web-search-firecrawl/provider
 */
import type { WebSearchProvider, WebSearchRequest, WebSearchResult, WebSearchSource } from '@deepseek-ai/dsh-web';
import type { FirecrawlSearchDataItem, FirecrawlSearchResponse } from './types.ts';
export { FIRECRAWL_DEFAULT_BASE_URL, FIRECRAWL_DEFAULT_MAX_SNIPPET_CHARS, } from './settings-shared.ts';
/** Stable id this provider registers under. */
export declare const FIRECRAWL_PROVIDER_ID = "firecrawl";
/** Resolved provider options (the plugin's `apply` supplies env-var and constant defaults). */
export interface FirecrawlSearchProviderOptions {
    /**
     * Firecrawl API key. Empty/absent is allowed: self-hosted instances running
     * with `USE_DB_AUTHENTICATION=false` accept keyless requests. The cloud API
     * still needs a key, so `available()` stays false without one unless the
     * base URL points at a loopback host.
     */
    apiKey: string;
    /**
     * Endpoint base. `/v1/search` is tried first; a self-hosted instance that
     * answers 404 there is retried at `/v2/search` (whose `data.web[]` is also
     * accepted).
     */
    baseURL: string;
    /** Default result count when a request carries no `maxResults`. */
    limit?: number;
    /** Upper bound on characters kept from one `description` when mapping `snippet`. */
    maxSnippetChars: number;
}
/**
 * Bound `text` to `max` characters. Firecrawl's `description` is frequently a long
 * page-markdown excerpt; the bound keeps one source's snippet from flooding model context
 * while preserving the excerpt's head.
 *
 * @param text - the excerpt to bound.
 * @param max - upper bound on the kept length.
 * @returns `text` unchanged when within the bound, else its first `max` characters.
 */
export declare function truncateTo(text: string, max: number): string;
/**
 * Map one Firecrawl `data[]` entry to a normalized source. `description` is trimmed,
 * blank-checked, and bounded by `maxSnippetChars`; an entry without a non-blank description
 * still maps to a citeable URL-only source (the seam supports sources without snippets, as
 * Perplexity citations may be URL-only).
 *
 * @param item - one entry of Firecrawl's `data[]`.
 * @param maxSnippetChars - bound on the mapped snippet length.
 * @returns the normalized source.
 */
export declare function mapFirecrawlResult(item: FirecrawlSearchDataItem, maxSnippetChars: number): WebSearchSource;
/**
 * Map a Firecrawl response envelope to a normalized search result. Accepts
 * both the v1 flat `data[]` and the v2 `data.web[]` shape.
 *
 * @param response - the parsed search response body.
 * @param maxSnippetChars - bound on one mapped snippet length.
 * @returns the normalized result.
 * @throws {@link WebError} `WEB_PROVIDER_ERROR` when the envelope reports failure.
 */
export declare function mapFirecrawlResponse(response: FirecrawlSearchResponse, maxSnippetChars: number): WebSearchResult;
/** The Firecrawl-backed search provider; HTTP redirects fail as `WEB_PROVIDER_ERROR`. */
export declare class FirecrawlSearchProvider implements WebSearchProvider {
    private readonly resolveOptions;
    readonly id = "firecrawl";
    /**
     * @param resolveOptions - the options for the NEXT operation, snapshotted
     * once at each operation's entry so one search never mixes two sections. A
     * thunk rather than a value because the plugin's volatile config can change
     * between searches, and re-registering the provider to carry a new endpoint
     * would make the seam's selection observable to the user as a flicker.
     */
    constructor(resolveOptions: () => FirecrawlSearchProviderOptions);
    available(): boolean;
    search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
    /**
     * POST one search operation. A keyless loopback instance sends no auth
     * header at all (self-hosted, `USE_DB_AUTHENTICATION=false`).
     */
    private postSearch;
}
